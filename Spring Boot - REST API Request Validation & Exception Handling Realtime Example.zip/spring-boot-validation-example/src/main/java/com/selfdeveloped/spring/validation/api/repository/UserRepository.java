package com.selfdeveloped.spring.validation.api.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.selfdeveloped.spring.validation.api.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>{

	User findByUserId(Integer id); 

}
