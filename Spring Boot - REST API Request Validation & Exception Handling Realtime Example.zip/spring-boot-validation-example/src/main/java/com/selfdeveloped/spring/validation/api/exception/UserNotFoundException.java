package com.selfdeveloped.spring.validation.api.exception;

public class UserNotFoundException extends Exception{

	public UserNotFoundException(String message) {
		super(message);
	}
}
